const handleSwitch = () => {

    let bulb = document.getElementById('lightbulb');
    let mySwitch = document.getElementById('switch');

    switch (bulb.getAttribute('class')) {

        case 'on':
            //lightbulb
            bulb.setAttribute('src', 'lightbulb_off.webp');
            bulb.setAttribute('class', 'off');
            //light switch
            mySwitch.setAttribute('class', 'off');
            mySwitch.setAttribute('src', 'off.png');
            //documenti body
            document.body.style.backgroundColor = "#000";

            break;

        default:
            //lightbulb
            bulb.setAttribute('src', 'lightbulb_on.webp');
            bulb.setAttribute('class', 'on');
            //light switch
            mySwitch.setAttribute('class', 'on');
            mySwitch.setAttribute('src', 'on.png');
            //documenti body
            document.body.style.backgroundColor = "#fff";
            break
    }
}